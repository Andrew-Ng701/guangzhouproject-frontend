export type ProjectStatus = '進行中' | '待確認' | '已完成'

export interface Project {
  id: string
  name: string
  stage: number
  status: ProjectStatus
  updatedAt: string
}

export interface TrainingStage {
  id: number
  title: string
  description: string
  status: 'completed' | 'current' | 'upcoming'
}

export interface Equipment {
  id: string
  name: string
  type: string
  materials: string[]
  location: string
  availability: string
  description: string
  specs: string[]
}

export interface ReservationDraft {
  service: string
  projectName: string
  fileName: string
  slot: string
  attendees: string
  notes: string
}

export interface Resource {
  id: string
  title: string
  category: string
  duration: string
  level: string
}

export interface Event {
  id: string
  title: string
  date: string
  location: string
  tag: string
}

export interface UserProfile {
  name: string
  role: string
  experience: string
  interests: string[]
  goal: string
}

export interface AiConversation {
  id: string
  role: 'user' | 'assistant'
  content: string
}
