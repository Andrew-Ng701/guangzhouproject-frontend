# Guangzhou Project Frontend Agents Guide

本文件是 `D:\guangzhouproject\frontend` 的前端工作規則。處理任何任務前，優先閱讀本文件；若本文件與全局偏好衝突，以本文件為準。

## 專案定位

- 這是以 Vite、React 與 TypeScript 建立的單頁前端專案。
- 專案目前刻意維持空白畫面，入口位於 `src/main.tsx`；除非任務明確要求，不要新增示範頁面、預設元件、假資料、路由或產品功能。
- 建置輸出目錄為 `dist`，可部署至任何支援靜態網站的服務。
- 隨功能成長，應逐步採用 feature-based 結構，避免在單一入口檔堆積產品邏輯。

## 預設查閱順序

1. 先讀本文件，確認專案規則與限制。
2. 讀任務直接相關檔案，例如 `package.json`、`vite.config.ts`、`src/main.tsx` 與 `src/index.css`。
3. 若已存在 `docs/`，先讀與任務相關的架構、API contract 或設計文件。
4. 只有在資訊缺失、可能過期、風險較高或查源碼更有效率時，才擴大搜尋範圍。

## 語言與協作

- 除非使用者明確要求其他語言，回覆、文件、說明與註解優先使用繁體中文。
- 技術名詞、TypeScript symbol、套件名、命令、檔案路徑與錯誤訊息可以保留英文。
- UI visible copy 的語言以產品需求為準；不要因協作語言是中文而自行改寫產品介面文案。
- 回覆需直接說明做了什麼、驗證了什麼，以及尚存的風險或限制。

## 工作原則

- Think Before Coding：先確認需求與現有實作。若資訊不足而無法可靠前進，明確指出缺口與影響。
- Simplicity First：使用能解決需求的最小程式碼；不要加入未被要求的功能、單次使用的抽象或 speculative flexibility。
- Surgical Changes：只改必要範圍，不順手重構或格式化無關程式碼；清理由本次改動造成的 unused import、variable、function 或 orphan code。
- Goal-Driven Execution：將任務轉成可驗證目標。功能或行為調整後，執行相應的 build、test 或其他可重現檢查。

## 命名規則

- React component、TypeScript type、interface、enum 使用 `UpperCamelCase`。
- function、parameter、local variable、object field、React props 與 state value 使用 `lowerCamelCase`。
- React hook 使用 `useXxx`。
- 共用字串常量使用 `UPPER_SNAKE_CASE`，特別是 route、storage key、cache key、status 與 request name。
- 環境變數使用 `VITE_UPPER_SNAKE_CASE`。

## 架構與檔案組織

- 優先跟隨現有 pattern、helper、component style 與 feature boundary。
- 新增共用抽象前，先確認至少有兩個實際使用點，或能明確降低複雜度。
- 功能擴張時建議使用下列結構：
  - `src/app`：app bootstrap、route 與全域 shell
  - `src/features`：依產品領域區分的頁面、元件、hooks 與服務
  - `src/components`：跨 feature 的共用 UI 元件
  - `src/api`：API client、endpoint wrappers 與 request/response helpers
  - `src/contracts`：後端 DTO、query、VO contract
  - `src/hooks`：跨 feature 的 React hooks
  - `src/lib`：小型、無框架相依的 helpers
  - `src/types`：跨 feature 的 TypeScript types
- feature-owned component、hook、type 應先放在 feature folder；只有真的跨兩個以上 feature 使用時才提升為共用。

## React 與 TypeScript

- 優先使用 function components 與 hooks。
- component props 必須保持明確型別；避免以 `any` 掩蓋資料形狀不清。
- server contract type 與 view model 應分開；UI 需要不同資料形狀時，透過 mapper 明確轉換。
- local state 應貼近使用位置；不要過早引入 global state。
- 有副作用的邏輯應集中在 hook 或 feature service，避免散落在多個 component handler。
- 不要在 render path 做昂貴計算或建立不穩定 reference；只在確有需要時使用 `useMemo` 或 `useCallback`。

## UI 與樣式

- 建立 UI 前先確認產品需求、設計資產與既有視覺規範；沒有需求時維持空白專案。
- 優先使用 accessible native controls；自訂 dropdown、drawer、tab、modal 要處理 keyboard、focus、aria 與 pointer states。
- 全域樣式只放真正跨頁共用的 base style、token 或 utility；元件專屬樣式應貼近元件或 feature。
- 固定格式 UI 元素應有穩定尺寸，避免 hover、載入文字或動態內容造成 layout shift。
- 所有 visible UI 預設視為可上線版本；不要加入 API payload、開發備忘、測試資訊或無產品意義的 placeholder。

## API 與前後端責任

- 開始涉及前後端整合的工作前，閱讀 `../shared/README.md`、`../shared/frontend-overview.md`、`../shared/backend-overview.md` 與 `../shared/api-contract.md`。
- `../shared/api-contract.md` 由後端唯一建立、維護與使用；前端只可閱讀，不得直接修改。若發現 API 缺口、契約不一致或設計問題，必須在 `../shared/frontend-overview.md` 的「待後端確認事項」記錄影響、目前觀察與期望結果，並主動通知後端。
- 前端只可維護 `../shared/frontend-overview.md`；可閱讀後端 overview，但不得直接修改。若發現後端 overview 有整合問題，應依同一回報流程提出。
- API contract、權限、評分、持久化、交易一致性與狀態轉移屬於後端權威；前端不可自行重建這些業務規則。
- 前端負責顯示、輸入收集、互動狀態、表單與上傳體驗、路由、使用者回饋與 request orchestration。
- 外部 API 欄位、request parameter、response field 與 status value 應維持 contract 原貌；只有明確需求時才建立 mapper。
- multipart request 不要手動設定 `Content-Type`，由 browser 自動帶入 boundary。
- 若發現 API contract 缺口或前後端行為不一致，應明確回報影響與期望修正，不要以 client workaround 掩蓋問題。

## 測試與驗證

- 基本建置驗證指令為 `npm.cmd run build`。
- 若日後配置 test runner，行為改動應補上或更新聚焦測試。
- 文件-only 變更至少確認目標文件存在且 heading 與內容正確，通常不需執行 build。
- 若無法執行測試或 build，最終回覆必須說明原因。

## Git 與工作樹

- 編輯前先確認工作樹狀態；可能存在使用者或自動化留下的未提交變更。
- 不要 revert、覆寫或刪除你沒有建立的變更。
- 不要使用 `git reset --hard`、`git checkout --` 或其他會丟棄變更的命令，除非使用者明確要求。
- commit message 應短且描述實際改動。

## 文件安全與 Windows 命令

- 禁止批量刪除文件或目錄；如確有刪除需要，只能針對單一明確路徑操作。
- 不要使用 `del /s`、`rd /s`、`rmdir /s`、`Remove-Item -Recurse` 或 `rm -rf`。
- 在 PowerShell 執行 npm scripts 時使用 `npm.cmd run build`、`npm.cmd run dev`、`npm.cmd run preview`。
- 搜尋文字或檔案優先使用 `rg`；若無法使用，再採用 PowerShell 原生命令。
- manual code edit 優先使用 `apply_patch`，不要用 shell redirect 或 Python 腳本寫檔。
