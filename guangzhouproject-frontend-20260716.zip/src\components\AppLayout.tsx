import type { ReactNode } from 'react'
import userAvatar from '../assets/user-avatar.png'
import { NAV_ITEMS } from '../data/mockData'

export type View = typeof NAV_ITEMS[number][0] | 'guide' | 'reservation' | 'admin'

export function AppLayout({ view, onNavigate, children }: { view: View; onNavigate: (view: View) => void; children: ReactNode }) {
  const active = NAV_ITEMS.find((item) => item[0] === view)?.[1] ?? '首頁儀表板'

  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><span className="brand-mark">3D</span><span>廣州基地<small>PRINT LAB</small></span></div><nav aria-label="主要導覽">{NAV_ITEMS.map(([id, label, icon]) => <button key={id} className={view === id ? 'nav-item active' : 'nav-item'} onClick={() => onNavigate(id)}><span>{icon}</span>{label}</button>)}</nav><div className="sidebar-note"><span>安全列印提醒</span><small>使用設備前，請先確認材料與現場安全規範。</small></div></aside>
    <div className="main-area"><header className="topbar"><div><p className="breadcrumb">學員端 / {active}</p><h1>{active}</h1></div><div className="top-actions"><button className="icon-button notification" aria-label="查看通知">🔔<i /></button><button className="user-chip" onClick={() => onNavigate('profile')}><img src={userAvatar} alt="" /><b>同學</b><small>試制學員</small></button></div></header><main>{children}</main></div>
    <nav className="mobile-nav" aria-label="行動版導覽">{NAV_ITEMS.filter(([id]) => id === 'dashboard' || id === 'base' || id === 'profile').map(([id, label, icon]) => <button key={id} className={view === id ? 'active' : ''} onClick={() => onNavigate(id)}><span>{icon}</span><small>{label.replace('首頁儀表板', '首頁').replace('基地與服務', '基地').replace('個人中心', '我的')}</small></button>)}</nav>
  </div>
}
