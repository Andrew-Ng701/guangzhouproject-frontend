import { useEffect, useRef } from 'react'
import * as THREE from 'three'

export function ModelPreview() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true })
    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100)
    camera.position.set(3, 2.4, 4)
    camera.lookAt(0, 0, 0)
    scene.add(new THREE.HemisphereLight(0xffffff, 0x8fb6d5, 2.5))
    const model = new THREE.Mesh(new THREE.CylinderGeometry(1, 1.15, 1.65, 48, 1, true), new THREE.MeshStandardMaterial({ color: 0x2f9ecb, roughness: 0.42, metalness: 0.15, side: THREE.DoubleSide }))
    model.rotation.y = 0.45
    scene.add(model)
    const grid = new THREE.GridHelper(4, 8, 0x5e9ed4, 0xb8d8ed)
    grid.position.y = -0.85
    scene.add(grid)
    const render = () => { renderer.setSize(canvas.clientWidth, canvas.clientHeight, false); renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); camera.aspect = canvas.clientWidth / canvas.clientHeight; camera.updateProjectionMatrix(); renderer.render(scene, camera) }
    render()
    const observer = new ResizeObserver(render)
    observer.observe(canvas)
    return () => { observer.disconnect(); renderer.dispose(); model.geometry.dispose(); (model.material as THREE.Material).dispose() }
  }, [])

  return <div className="model-preview"><canvas ref={canvasRef} aria-label="智慧盆栽外殼的 3D 靜態模型預覽" /><span>示意模型・120 × 120 × 165 mm</span></div>
}
