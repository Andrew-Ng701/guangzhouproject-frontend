# 全 App API 規劃（前端提案）

最後更新：2026-07-16  
狀態：**提案，非正式契約**。後端確認後，須由後端將已採納內容寫入 `../shared/api-contract.md`；此前前端不可依本文件假定欄位或狀態已可用。

## 審視結論：管理端與學生端對應度

| 學生端能力 | 現有管理端 | 結論與必需補齊項目 |
| --- | --- | --- |
| 登入、註冊、首次偏好 | 僅以 `admin@printlab.local` 建立 mock session | 不對應；需帳戶、角色、個人資料與 onboarding 管理。 |
| 首頁：個人試制計畫、推薦內容、近期活動、安全提醒 | 三類內容數量統計 | 不對應；需學生個人摘要及管理端營運摘要。 |
| 試制培訓：計畫、7 階段、筆記、進度 | 無 | 不對應；需計畫、階段範本、學生進度及管理者檢視。 |
| 設備目錄、篩選、詳情、安全提示 | 設備 CRUD | 部分對應；缺設備圖片、結構化規格、可預約性／時段、安全規則、學生可見性篩選。管理端欄位 `specifications: string` 與學生端 `specs: string[]` 不一致。 |
| 學習資源、分類、開始學習 | 學習資源 CRUD | 部分對應；缺封面／內容型態、學生閱讀進度、收藏、可見性與發布時間。 |
| 錯誤排查、標記有用、請技術員協助 | 無 | 不對應；需知識庫、回饋與技術支援單。 |
| 基地空間、服務申請、聯絡 | 無 | 不對應；需基地／空間／服務內容與申請單。 |
| 活動列表與報名 | 活動 CRUD | 部分對應；缺活動容量、報名期間、報名名單、取消／候補與簽到。 |
| 個人中心、收藏、通知 | 無 | 不對應；需個人檔案、收藏、通知與已讀狀態。 |
| AI 試制助手 | 無 | 不對應；需受控的對話、知識來源／安全免責與人工轉介；不可把模型金鑰放在前端。 |
| 預約（原學生端已停用，但 UI 型別與舊管理摘要皆保留） | 無 | 需求未定前不實作；若恢復，必須是設備時段、審核及衝突控制的一體化模組。 |

目前正式入口只會顯示登入／管理端；學生端原型存在於封存檔與共用元件中，尚未重新接回入口。因此，以下規劃同時是「恢復學生端」與「補足管理端」的後端範圍清單。

## 契約共同規則

- Base path：`/api`；沿用 `Result<T>`，成功 `code: 1`，失敗 `code: 0`。
- 除公開讀取、登入／註冊外，其餘端點需登入。角色至少為 `STUDENT`、`ADMIN`；若有技術員，另加 `TECHNICIAN`，不得由前端自行判斷權限。
- 清單端點統一採用 `page`、`pageSize`、`q`，回傳 `{ items, page, pageSize, total }`；前端學生首頁可使用專用摘要端點，避免 N+1 請求。
- 所有時間以 ISO 8601 UTC 傳遞（例如 `2026-07-16T08:00:00Z`），顯示時才轉 `Asia/Hong_Kong`。`createdAt`、`updatedAt`、`publishedAt` 由後端產生。
- 管理端內容保留 `DRAFT`、`PUBLISHED`、`ARCHIVED`；活動另有 `ENDED`、`CANCELLED`。實際可達狀態轉換、衝突及錯誤碼由後端定義。
- 寫入端點應回傳完整最新資源；更新／狀態轉換需要樂觀鎖版本 `version` 或等價機制，以免多人覆蓋。
- 檔案先透過受權限保護的 upload API 取得 `fileId`／URL，再在內容 API 引用；multipart 由瀏覽器自帶 boundary。

## 資源與端點規劃

### 1. 身分、帳戶與個人資料

| Method | Path | 權限 | 用途 |
| --- | --- | --- | --- |
| `POST` | `/auth/register` | 公開 | 學員註冊。 |
| `POST` | `/auth/login` | 公開 | 登入並建立 session／token。 |
| `POST` | `/auth/logout` | 已登入 | 登出目前 session。 |
| `GET` | `/auth/me` | 已登入 | 取得使用者、角色、權限與 onboarding 狀態。 |
| `PATCH` | `/me/profile` | 已登入 | 更新姓名、頭像、經驗、興趣、目標。 |
| `PUT` | `/me/onboarding` | 已登入 | 儲存首次身份與列印經驗。 |
| `GET` | `/admin/users` | ADMIN | 搜尋／篩選使用者與角色。 |
| `PATCH` | `/admin/users/{userId}/role` | ADMIN | 變更角色；需保護最後一位管理員等規則。 |

### 2. 學員首頁、試制計畫與培訓

| Method | Path | 權限 | 用途 |
| --- | --- | --- | --- |
| `GET` | `/me/dashboard` | STUDENT | 回傳進行中計畫、推薦資源、近期活動、安全提醒與未讀數。 |
| `GET` / `POST` | `/me/projects` | STUDENT | 列出／建立自己的試制計畫。 |
| `GET` / `PATCH` | `/me/projects/{projectId}` | 擁有者 | 讀取／更新計畫基本資料。 |
| `GET` | `/me/projects/{projectId}/stages` | 擁有者 | 取得階段、完成狀態、筆記與建議。 |
| `PATCH` | `/me/projects/{projectId}/stages/{stageId}` | 擁有者 | 儲存筆記、確認或退回階段；後端驗證狀態轉換。 |
| `GET` | `/training/templates` | 已登入 | 取得可用的培訓／階段範本。 |
| `GET` / `POST` | `/admin/training/templates` | ADMIN | 管理培訓範本與階段順序。 |
| `GET` | `/admin/projects` | ADMIN | 依學生、狀態、日期檢視計畫與進度。 |

### 3. 設備、學習資源與活動（管理端既有範圍）

公開／學生讀取端點只回傳 `PUBLISHED` 的資料；管理端清單可依 status 篩選並包含草稿。

| Method | Path | 權限 | 用途 |
| --- | --- | --- | --- |
| `GET` | `/equipment`、`/equipment/{id}` | 已登入 | 學生設備目錄與詳情，支援 `type`、`material`、`availability`、`q`。 |
| `GET` / `POST` | `/admin/equipment` | ADMIN | 管理設備清單／建立。 |
| `GET` / `PATCH` | `/admin/equipment/{id}` | ADMIN | 取得／編輯設備。 |
| `PATCH` | `/admin/equipment/{id}/status` | ADMIN | 發布、封存與維護可用性。 |
| `GET` | `/resources`、`/resources/{id}` | 已登入 | 學習資源目錄與詳情，支援 `category`、`level`、`q`。 |
| `GET` / `POST` | `/admin/resources` | ADMIN | 管理資源。 |
| `GET` / `PATCH` | `/admin/resources/{id}` | ADMIN | 取得／編輯資源。 |
| `PATCH` | `/admin/resources/{id}/status` | ADMIN | 發布或封存資源。 |
| `PUT` | `/me/resources/{id}/progress` | STUDENT | 儲存學習進度／完成時間。 |
| `POST` / `DELETE` | `/me/resources/{id}/favorite` | STUDENT | 收藏／取消收藏。 |
| `GET` | `/events`、`/events/{id}` | 已登入 | 學生活動清單與詳情。 |
| `GET` / `POST` | `/admin/events` | ADMIN | 管理活動。 |
| `GET` / `PATCH` | `/admin/events/{id}` | ADMIN | 取得／編輯活動、容量與報名規則。 |
| `PATCH` | `/admin/events/{id}/status` | ADMIN | 發布、結束、取消或封存。 |
| `POST` / `DELETE` | `/events/{id}/registrations/me` | STUDENT | 報名／取消自己的報名。 |
| `GET` | `/admin/events/{id}/registrations` | ADMIN | 管理名單、候補、簽到與匯出。 |
| `PATCH` | `/admin/events/{id}/registrations/{registrationId}` | ADMIN | 調整候補、報名或簽到狀態。 |

設備 DTO 應至少含 `name`、`type`、`location`、`materials[]`、`description`、`specifications[]`、`safetyNotes[]`、`availability`、`coverFileId`、`status`；學習資源應含 `contentType`、`contentUrl/fileId`、`coverFileId`、`category`、`level`、`durationMinutes`、`sortOrder`、`status`；活動另需 `endsAt`、`capacity`、`registrationStartsAt`、`registrationEndsAt`。這些欄位須由後端最終確認。

### 4. 排障、基地服務、通知與檔案

| Method | Path | 權限 | 用途 |
| --- | --- | --- | --- |
| `GET` | `/troubleshooting/articles`、`/troubleshooting/articles/{id}` | 已登入 | 依症狀、設備、材料取回排障內容。 |
| `POST` | `/troubleshooting/articles/{id}/feedback` | STUDENT | 回報內容是否有幫助。 |
| `POST` | `/support-tickets` | STUDENT | 無法排除時建立技術員協助單。 |
| `GET` / `PATCH` | `/admin/support-tickets`、`/admin/support-tickets/{id}` | ADMIN／TECHNICIAN | 分派、回覆及更新處理狀態。 |
| `GET` | `/base/locations`、`/base/services` | 已登入 | 取得基地空間、服務與聯絡資訊。 |
| `GET` / `POST` / `PATCH` | `/admin/base/locations`、`/admin/base/services` | ADMIN | 維護空間與服務資訊。 |
| `POST` | `/service-applications` | STUDENT | 提出入駐／顧問服務申請。 |
| `GET` / `PATCH` | `/admin/service-applications`、`/admin/service-applications/{id}` | ADMIN | 審核申請。 |
| `GET` | `/me/notifications` | STUDENT | 分頁取得通知。 |
| `POST` | `/me/notifications/read` | STUDENT | 批次標記已讀。 |
| `GET` / `POST` | `/admin/notifications` | ADMIN | 建立公告、排程及指定受眾。 |
| `POST` | `/files` | 已登入 | 上傳頭像、封面與附件。 |
| `DELETE` | `/files/{fileId}` | 擁有者／ADMIN | 移除未被引用的檔案。 |

### 5. AI 與預約（需先確認產品決策）

| Method | Path | 權限 | 用途 |
| --- | --- | --- | --- |
| `POST` | `/ai/conversations` | STUDENT | 建立對話，回傳對話 ID 與第一則建議。 |
| `GET` | `/ai/conversations/{id}` | 擁有者／ADMIN | 讀取對話歷史；管理員僅可在明確的審核／支援授權下讀取。 |
| `POST` | `/ai/conversations/{id}/messages` | 擁有者 | 傳送訊息；後端串接模型、套用速率限制與內容安全。 |
| `POST` | `/ai/conversations/{id}/handoff` | STUDENT | 將對話摘要建立為支援單。 |
| `GET` / `POST` / `PATCH` | `/admin/ai/knowledge-sources` | ADMIN | 管理可檢索知識來源與發布狀態。 |
| `GET` | `/equipment/{id}/availability` | 已登入 | **僅在恢復預約後**查詢可用時段。 |
| `POST` | `/reservations` | STUDENT | **僅在恢復預約後**建立預約／審核申請。 |
| `GET` / `PATCH` | `/admin/reservations`、`/admin/reservations/{id}` | ADMIN／TECHNICIAN | **僅在恢復預約後**審核、取消、調整。 |

AI 回應應帶 `disclaimer`、`sources[]`（如適用）及 `requiresHumanReview`；API 金鑰、提示詞與模型供應商設定必須只存在後端。預約需以交易／鎖定避免同一設備時段重複核准。

### 6. 管理總覽、稽核與跨模組操作

| Method | Path | 權限 | 用途 |
| --- | --- | --- | --- |
| `GET` | `/admin/dashboard` | ADMIN | 回傳待審核數、設備狀態、活動／支援單、培訓及內容發布統計。 |
| `GET` | `/admin/audit-logs` | ADMIN | 檢視發布、角色、審核、取消等不可抵賴操作。 |
| `GET` | `/admin/content/summary` | ADMIN | 快速取得三類內容的草稿、發布、封存數，取代前端自行統計。 |

## 建議交付順序

1. **基礎**：帳戶／RBAC、`auth/me`、統一錯誤、分頁、檔案與 audit 基礎。
2. **MVP 閉環**：設備、資源、活動的學生讀取與管理 CRUD／發布／報名；管理總覽；學生入口接回。
3. **核心學習流程**：個人資料、試制計畫與培訓進度、通知、資源進度／收藏。
4. **營運支援**：排障知識庫、支援單、基地服務申請。
5. **需產品決策的擴展**：AI 與設備預約；先完成隱私、額度、人工交接與衝突規則，才開始前端串接。

## 後端確認清單

- Token 或 cookie session 的認證方式、refresh／過期、CSRF 與 CORS 正式環境策略。
- 確切角色集合、資料可見範圍及管理員／技術員的責任分界。
- 各資源 DTO、必填欄位、列舉值、狀態機、錯誤碼與樂觀鎖策略。
- 活動報名、預約衝突、候補與取消的交易規則。
- AI 供應商、資料保留期、敏感資料處理、知識來源及人工轉介規則。
- 儲存服務、檔案大小／格式／掃毒、URL 有效期與刪除策略。
