import { useState, type ReactNode } from 'react'
import userAvatar from '../assets/user-avatar.png'
import { NAV_ITEMS } from '../data/mockData'

export type View = typeof NAV_ITEMS[number][0] | 'guide' | 'reservation' | 'admin'

function NavigationIcon({ view }: { view: View }) {
  const iconProps = { viewBox: '0 0 24 24', width: 20, height: 20, fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true }
  if (view === 'dashboard') return <svg {...iconProps}><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1Z" /><path d="M9 21v-6h6v6" /></svg>
  if (view === 'training') return <svg {...iconProps}><path d="m12 3 8 4.5-8 4.5-8-4.5Z" /><path d="m4 12 8 4.5 8-4.5" /><path d="m4 16.5 8 4.5 8-4.5" /></svg>
  if (view === 'equipment') return <svg {...iconProps}><path d="M4 4h16v16H4z" /><path d="M8 4v16M16 4v16M4 8h16M4 16h16" /></svg>
  if (view === 'resources') return <svg {...iconProps}><path d="M5 4.5A3.5 3.5 0 0 1 8.5 4H20v15H8.5A3.5 3.5 0 0 0 5 22Z" /><path d="M5 4.5V22M9 8h7M9 12h7" /></svg>
  if (view === 'troubleshoot') return <svg {...iconProps}><path d="M14.7 6.3a4 4 0 0 0-5 5L3 18v3h3l6.7-6.7a4 4 0 0 0 5-5l-2.8 2.2-3.1-.6-.6-3.1Z" /></svg>
  if (view === 'base') return <svg {...iconProps}><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3Z" /><path d="M9 3v15M15 6v15" /></svg>
  if (view === 'events') return <svg {...iconProps}><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01" /></svg>
  return <svg {...iconProps}><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></svg>
}

export function AppLayout({ view, onNavigate, onNotifications, unreadCount, children }: { view: View; onNavigate: (view: View) => void; onNotifications: () => void; unreadCount: number; children: ReactNode }) {
  const active = NAV_ITEMS.find((item) => item[0] === view)?.[1] ?? '首頁儀表板'
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  return <div className={sidebarCollapsed ? 'app-shell sidebar-collapsed' : 'app-shell'}>
    <aside className="sidebar"><button className="sidebar-toggle" onClick={() => setSidebarCollapsed((value) => !value)} aria-label={sidebarCollapsed ? '展開導覽列' : '收合導覽列'} title={sidebarCollapsed ? '展開導覽列' : '收合導覽列'}><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={sidebarCollapsed ? 'm9 18 6-6-6-6' : 'm15 18-6-6 6-6'} /></svg></button><div className="brand"><span className="brand-mark">3D</span><span>廣州基地<small>PRINT LAB</small></span></div><nav aria-label="主要導覽">{NAV_ITEMS.map(([id, label]) => <button key={id} className={view === id ? 'nav-item active' : 'nav-item'} onClick={() => onNavigate(id)}><span><NavigationIcon view={id} /></span>{label}</button>)}</nav><div className="sidebar-note"><span>安全列印提醒</span><small>使用設備前，請先確認材料與現場安全規範。</small></div></aside>
    <div className="main-area"><header className="topbar"><div><p className="breadcrumb">學員端 / {active}</p><h1>{active}</h1></div><div className="top-actions"><button className="icon-button notification" onClick={onNotifications} aria-label={unreadCount ? `查看通知，${unreadCount} 則未讀` : '查看通知'}><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></svg>{unreadCount > 0 && <i>{unreadCount}</i>}</button><button className="user-chip" onClick={() => onNavigate('profile')}><img src={userAvatar} alt="" /><b>同學</b><small>試制學員</small></button></div></header><main>{children}</main></div>
    <nav className="mobile-nav" aria-label="行動版導覽">{NAV_ITEMS.filter(([id]) => id === 'dashboard' || id === 'base' || id === 'profile').map(([id, label]) => <button key={id} className={view === id ? 'active' : ''} onClick={() => onNavigate(id)}><span><NavigationIcon view={id} /></span><small>{label.replace('首頁儀表板', '首頁').replace('基地與服務', '基地').replace('個人中心', '我的')}</small></button>)}</nav>
  </div>
}
