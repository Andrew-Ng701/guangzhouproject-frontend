import type { Equipment, Event, Project, Resource, TrainingStage, UserProfile } from '../types/models'

export const NAV_ITEMS = [
  ['dashboard', '首頁儀表板', '⌂'], ['training', '試制培訓', '◌'], ['equipment', '設備目錄', '▦'],
  ['resources', '學習資源', '▤'], ['troubleshoot', '錯誤排查', '⚑'], ['base', '基地與服務', '⌘'], ['events', '活動資訊', '◇'], ['profile', '個人中心', '◎'],
] as const

export const projects: Project[] = [
  { id: 'P-0248', name: '智慧盆栽外殼試制', stage: 3, status: '進行中', updatedAt: '今天 10:24' },
  { id: 'P-0231', name: '無障礙握把優化', stage: 6, status: '待確認', updatedAt: '昨天' },
]

export const trainingStages: TrainingStage[] = [
  { id: 1, title: '需求釐清', description: '確認使用情境與目標', status: 'completed' },
  { id: 2, title: '設計準備', description: '整理尺寸與初步草圖', status: 'completed' },
  { id: 3, title: '設備匹配', description: '選擇製程與材料', status: 'current' },
  { id: 4, title: '檔案檢查', description: '確認可列印條件', status: 'upcoming' },
  { id: 5, title: '試制一輪', description: '驗證結構與尺寸', status: 'upcoming' },
  { id: 6, title: '優化調整', description: '依測試結果修改', status: 'upcoming' },
  { id: 7, title: '成果確認', description: '完成紀錄與回饋', status: 'upcoming' },
]

export const equipment: Equipment[] = [
  { id: 'EQ-01', name: 'Raise3D Pro3 Plus', type: 'FDM', materials: ['PLA', 'PETG', 'TPU'], location: 'A 區・製作間｜虛擬地址：廣州市天河區珠江東路 30 號', availability: '目前可用', description: '適合原型、治具與中大型結構件的雙噴頭 FDM 設備。', specs: ['建置尺寸 300 × 300 × 605 mm', '雙噴頭，支援複合列印', '層高 0.1–0.4 mm'] },
  { id: 'EQ-02', name: 'Formlabs Form 4', type: 'SLA', materials: ['標準樹脂', '韌性樹脂'], location: 'B 區・精密間｜虛擬地址：廣州市天河區花城大道 18 號', availability: '目前可用', description: '高精度樹脂列印，適用外觀模型與細節零件。', specs: ['建置尺寸 200 × 125 × 210 mm', '精細表面品質', '需完成樹脂安全檢查'] },
  { id: 'EQ-03', name: 'xTool S1', type: '雷射加工', materials: ['壓克力', '木板'], location: 'C 區・加工間｜虛擬地址：廣州市天河區黃埔大道 66 號', availability: '目前可用', description: '用於平面切割與打樣，適合搭配列印成品製作外殼。', specs: ['工作範圍 498 × 330 mm', '封閉式安全設計', '需現場安全說明'] },
]

export const resources: Resource[] = [
  { id: 'R1', title: '第一次 3D 列印：從模型到成品', category: '入門指南', duration: '18 分鐘', level: '新手' },
  { id: 'R2', title: 'FDM 支撐與方向設計要點', category: '設計技巧', duration: '12 分鐘', level: '基礎' },
  { id: 'R3', title: '列印失敗診斷手冊', category: '問題排除', duration: '8 分鐘', level: '進階' },
]

export const events: Event[] = [
  { id: 'E1', title: '生成式設計與快速試制工作坊', date: '7 月 22 日・14:00', location: '創客基地 2F', tag: '工作坊' },
  { id: 'E2', title: '材料選擇公開諮詢', date: '7 月 25 日・10:30', location: '線上直播', tag: '分享會' },
  { id: 'E3', title: '七月開放日：設備實作體驗', date: '7 月 30 日・13:00', location: '創客基地', tag: '體驗活動' },
]

export const profile: UserProfile = { name: '同學', role: '試制學員', experience: '曾使用入門 FDM 設備', interests: ['產品原型', '生活輔具'], goal: '完成可測試的功能原型' }
