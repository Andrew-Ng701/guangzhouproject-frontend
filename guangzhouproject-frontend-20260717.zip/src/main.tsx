import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { App } from './app/App'
import './app/updates.css'
import './app/aiAssistant.css'
import './app/motion.css'
import './app/notification.css'
import './app/troubleshoot.css'
import './app/refinements.css'
import './app/login.css'
import './index.css'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
