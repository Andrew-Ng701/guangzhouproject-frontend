import { useState, type FormEvent } from 'react'
import { AdminApp } from '../features/admin/AdminApp'
import { UserApp } from '../features/user/UserApp'
import type { AdminSession } from '../features/admin/types'
import { ContentCatalogProvider } from '../features/content/ContentCatalog'

function ArrowRightIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
}

function LockIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="10" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3" /></svg>
}

function EyeIcon({ hidden }: { hidden: boolean }) {
  return <svg viewBox="0 0 24 24" aria-hidden="true">{hidden ? <><path d="m3 3 18 18" /><path d="M10.6 10.6a2 2 0 0 0 2.8 2.8" /><path d="M9.9 4.2A10.7 10.7 0 0 1 12 4c5.5 0 9.3 5.1 9.8 6-.3.6-1.3 2-2.8 3.3M6.2 6.2C4.2 7.6 2.7 9.6 2.2 10c.5.9 4.3 6 9.8 6 1 0 1.9-.2 2.8-.5" /></> : <><path d="M2.2 12S6 5 12 5s9.8 7 9.8 7-3.8 7-9.8 7S2.2 12 2.2 12Z" /><circle cx="12" cy="12" r="3" /></>}</svg>
}

export function App() {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [showPassword, setShowPassword] = useState(false)
  const [notice, setNotice] = useState('')
  const [adminSession, setAdminSession] = useState<AdminSession | null>(null)
  const [userLoggedIn, setUserLoggedIn] = useState(false)
  const isRegistering = mode === 'register'

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    const email = String(formData.get('email') ?? '').trim().toLowerCase()
    if (!isRegistering && email === 'user') {
      setUserLoggedIn(true)
      return
    }
    if (!isRegistering && email === 'admin') {
      setAdminSession({ name: '系統管理員', email, role: 'admin' })
      return
    }
    setNotice(isRegistering ? '帳戶申請已送出，請留意後續通知。' : '帳戶或密碼不正確，請重新輸入。')
  }

  const switchMode = () => {
    setMode((currentMode) => currentMode === 'login' ? 'register' : 'login')
    setNotice('')
    setShowPassword(false)
  }

  const content = adminSession ? <AdminApp session={adminSession} onLogout={() => { setAdminSession(null); setNotice('') }} />
    : userLoggedIn ? <UserApp onLogout={() => { setUserLoggedIn(false); setNotice('') }} />
      : <main className="login-page">
    <section className="login-brand-panel" aria-labelledby="platform-title">
      <div className="login-brand"><span className="login-brand-mark">3D</span><span>智造實驗室<small>PRINT LAB</small></span></div>
      <div className="login-introduction"><h1 id="platform-title">讓每一次創作，<br />都更接近完成。</h1><p>管理專案進度、設備預約與學習資源，從登入開始，專注完成下一個好作品。</p></div>
      <div className="login-orbit" aria-hidden="true"><span>01</span><i /><small>CREATE<br />WITH PURPOSE</small></div>
      <p className="login-copyright">© 2026 智造實驗室 · 讓創意落地</p>
    </section>
    <section className="login-form-panel" aria-labelledby="login-title">
      <div className="login-card">
        <div className="login-card-heading"><span className="login-lock"><LockIcon /></span><div><p>{isRegistering ? '開始你的創作旅程' : '歡迎回來'}</p><h2 id="login-title">{isRegistering ? '創建新帳戶' : '登入你的帳戶'}</h2></div></div>
        <form onSubmit={handleSubmit}>
          {isRegistering && <><label htmlFor="name">姓名</label><input id="name" name="name" type="text" autoComplete="name" placeholder="輸入你的姓名" required /></>}
          <label htmlFor="email">電子郵件</label><input id="email" name="email" type={isRegistering ? 'email' : 'text'} autoComplete={isRegistering ? 'email' : 'off'} placeholder="name@example.com" required />
          <label htmlFor="password">密碼</label><div className="password-field"><input id="password" name="password" type={showPassword ? 'text' : 'password'} autoComplete={isRegistering ? 'new-password' : 'current-password'} minLength={isRegistering ? 8 : undefined} placeholder={isRegistering ? '至少 8 個字元' : '輸入你的密碼'} required={isRegistering} /><button type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? '隱藏密碼' : '顯示密碼'}><EyeIcon hidden={showPassword} /></button></div>
          {isRegistering && <><label htmlFor="confirm-password">確認密碼</label><input id="confirm-password" name="confirmPassword" type={showPassword ? 'text' : 'password'} autoComplete="new-password" minLength={8} placeholder="再次輸入密碼" required /><label className="terms-agreement"><input type="checkbox" name="terms" required /><span>我已閱讀並同意服務條款與隱私政策</span></label></>}
          <button className="login-submit" type="submit">{isRegistering ? '創建帳戶' : '登入平台'} <ArrowRightIcon /></button>
          {notice && <p className="login-notice" role="status">{notice}</p>}
        </form>
        <button className="mode-switch" type="button" onClick={switchMode}>{isRegistering ? '返回登入' : '創建帳戶'}</button>
      </div>
    </section>
      </main>

  return <ContentCatalogProvider>{content}</ContentCatalogProvider>
}
