import './base.css'
import { useState, type ReactNode } from 'react'

type IconName = 'home' | 'spark' | 'tools' | 'scan' | 'factory' | 'headset' | 'network' | 'check' | 'ai' | 'book'

function BaseIcon({ name }: { name: IconName }) {
  const paths: Record<IconName, ReactNode> = {
    home: <><path d="m3 11 9-7 9 7" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
    spark: <><path d="m12 3 1.3 4.2L17 9l-3.7 1.8L12 15l-1.3-4.2L7 9l3.7-1.8L12 3Z" /><path d="m19 15 .7 2.3L22 18.5l-2.3 1.2L19 22l-.7-2.3-2.3-1.2 2.3-1.2L19 15Z" /></>,
    tools: <><path d="M14 6a4 4 0 0 0-5 5L3 17l4 4 6-6a4 4 0 0 0 5-5l-3 3-3-3 3-3Z" /></>,
    scan: <><path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5" /><circle cx="12" cy="12" r="3" /></>,
    factory: <><path d="M3 21V9l6 3V8l6 4V5h6v16H3Z" /><path d="M7 17h2m4 0h2m4 0h2" /></>,
    headset: <><path d="M4 14v-2a8 8 0 0 1 16 0v2" /><path d="M4 14h3v6H5a2 2 0 0 1-2-2v-2a2 2 0 0 1 1-2Zm16 0h-3v6h2a2 2 0 0 0 2-2v-2a2 2 0 0 0-1-2Z" /></>,
    network: <><circle cx="12" cy="6" r="3" /><circle cx="6" cy="18" r="3" /><circle cx="18" cy="18" r="3" /><path d="m10.5 8.7-3 6.6m6-6.6 3 6.6M9 18h6" /></>,
    check: <><circle cx="12" cy="12" r="9" /><path d="m8 12 2.5 2.5L16 9" /></>,
    ai: <><rect x="4" y="5" width="16" height="14" rx="3" /><path d="M9 10h.01M15 10h.01M9 15h6M12 2v3" /></>,
    book: <><path d="M4 5a3 3 0 0 1 3-2h5v17H7a3 3 0 0 0-3 2V5Zm16 0a3 3 0 0 0-3-2h-5v17h5a3 3 0 0 1 3 2V5Z" /></>,
  }
  return <svg viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>
}

const supportServices = [
  ['配套服務', '理念效率', '從需求梳理、方案選擇到原型試制，協助團隊縮短驗證週期。', 'spark'],
  ['設備使用服務', '共享設備', '提供設備能力、材料、尺寸、精度、檔案格式、狀態與安全條件說明。', 'tools'],
  ['技術諮詢服務', '專業陪跑', '由技術人員協助工藝評估、風險排查、參數確認與結果復盤。', 'network'],
  ['設備操作培訓', '安全上手', '完成操作流程與安全規範學習，建立可重複的試制紀錄。', 'check'],
] as const

const zones = [
  ['01', '3D・創意試制區', '涵蓋產品創新研發與原型落地：建模、3D 掃描、工業級 DLP／光固化／金屬與高速 3D 列印，支援 PLA、ABS、PETG、TPU、TPE、樹脂與金屬等材料。', 'scan'],
  ['02', '精密檢測試驗區', '以高精度量測為核心，配置三坐標測量、影像與分析設備，支援尺寸、形貌、結構、性能與品質驗證。', 'check'],
  ['03', '智能製造試制區', '支援數位化設計、加工與製造驗證，提供設備實作、工藝評估及智慧製造場景體驗。', 'factory'],
  ['04', 'MR／VR 融合實驗室', '配置 MR 眼鏡、VR 頭戴裝置與互動顯示設備，用於沉浸式展示、協作設計、模擬驗證與產品發布。', 'headset'],
  ['05', '創業實踐聯絡區', '匯聚創業導師、技術顧問與基地資源，支援交流、路演、人才培訓、專案對接及成果轉化。', 'network'],
] as const

const smartCapabilities = [
  ['創意設計', '聚焦產品定位、需求與概念生成。'],
  ['概念驗證', '透過原型快速驗證核心假設。'],
  ['內容整理', '沉澱規格、資料與過程紀錄。'],
  ['人才培訓', '提供設備、工藝與安全學習。'],
  ['算法加速', '以 AI 提升分析與方案迭代效率。'],
  ['服務中心', '串連預約、技術支援與基地資源。'],
] as const

const curriculum = [
  {
    title: '01｜專案定位與目標用戶',
    content: <><p>網頁 App 面向粵港澳大灣區創新創業基地學員，目標是降低第一次使用基地設備的門檻，讓使用者能獨立完成一次產品原型試制。</p><ul><li>主要用戶：港澳青年創業團隊、內地創業團隊、高品質人才、大學生及科研團隊。</li><li>共同需求：了解基地資源、快速驗證原型、技術驗證或成果轉化、學習設備與樣品製作流程。</li><li>使用者特點：技術基礎與創業方向不同，通常不熟悉設備能力、預約流程與安全規範。</li></ul></>,
  },
  {
    title: '02｜身份偏好與個人化推薦',
    content: <><p>首次進入可設定身份、創業階段、行業方向、設備經驗與產品類型。</p><ul><li>創業階段：創意、原型驗證、產品測試、小批量試制。</li><li>行業方向：人工智能、智能硬件、新能源新材料、物聯網、高端裝備製造、數字創意、生物醫藥。</li><li>產品類型：外觀模型、結構件、功能樣品、展示樣品、檢測樣品。</li><li>系統據此推薦設備、教程、注意事項、政策資源及 AI 測試建議。</li></ul></>,
  },
  {
    title: '03｜設備查找與能力邊界',
    content: <><p>學員可依產品類型、材料、尺寸、精度、難度、技術支援、新手適用性與可預約時間篩選。</p><ul><li>設備清單：名稱、功能區、用途、材料、最大尺寸、精度、檔案格式、使用條件與狀態。</li><li>能力邊界：能做／不能做、適用／不適用產品、常見失敗原因，以及使用前、中、後的要求。</li><li>3D 列印適合外觀樣品、結構驗證、智能硬件外殼、文創模型與小型裝配測試；不適合直接量產、超大尺寸或未經安全確認的特殊用途零件。</li></ul></>,
  },
  {
    title: '04｜3D 列印案例：桌面環境傳感器外殼',
    content: <><p>案例要求白色外觀、按鈕孔、USB 接口、可容納主板，先驗證外觀與裝配空間，不以直接量產為目標。</p><ul><li>先確認尺寸、3D 模型、PLA／ABS／樹脂選擇、外觀精度、承重、展示需求與後處理。</li><li>App 推薦設備與材料，提示格式、尺寸限制、上傳資料與現場安全，並建議是否先做 AI 可行性測試。</li></ul></>,
  },
  {
    title: '05｜設備預約與使用安全',
    content: <><p>預約前需準備產品說明、STL／OBJ、尺寸、材料偏好、用途、技術支援需求與預計完成時間。</p><ul><li>使用前：檢查格式、尺寸、材料、時間、支撐、協助需求與安全規範。</li><li>使用中：不擅自調參、不觸碰高溫部件；異常即聯絡技術人員，確認方向與材料並記錄參數。</li><li>使用後：取件檢查、拍照、保存參數與問題，規劃下一版並在 App 儲存紀錄。</li></ul></>,
  },
  {
    title: '06｜AI 實用性測試',
    content: <><p>AI 依設備資料、尺寸、材料、歷史案例、操作紀錄與常見失敗原因，在正式預約前提供初步判斷。</p><ul><li>輸入：產品名稱／用途／尺寸、材料、STL／OBJ 或文字描述、期望效果、場景與強度／精度／外觀／耐溫要求。</li><li>分析：工藝適配、推薦設備、尺寸與材料、檔案問題、結構修改、加工風險及小樣測試需求。</li><li>結果：可行（進入預約）、需調整（修改尺寸、材料、壁厚、結構或檔案）、不建議製作（更換工藝或重新設計）。</li></ul></>,
  },
  {
    title: '07｜政策資源、教學互動與交付',
    content: <><ul><li>港澳青年可關注大灣區創業支持；在孵專案關注公共服務與設備；高校團隊關注共享設備與技術支援；初創企業關注原型、路演與產品驗證。</li><li>教學互動包含選擇題、判斷題、小練習、填空與「需調整」情境題。</li><li>完整開發可交付教學課件、App 原型、操作流程、設備與 AI 頁面、檢查表、使用手冊、專案／測試報告及演示影片。</li></ul></>,
  },
] as const

const learningPath = ['認識基地平台', '了解 App 作用', '選擇學員身份', '完成偏好設定', '了解 3D 列印案例', '學會查找設備', '閱讀能力邊界', '準備預約資料', '完成預約流程', '掌握現場注意事項', '保存結果與復盤', '使用 AI 實用性測試', '依 AI 建議修改方案', '以檢查表確認掌握']

export function BasePage() {
  const [openSection, setOpenSection] = useState(0)

  return <div className="base-page">
    <section className="base-intro" aria-labelledby="base-title">
      <div className="base-kicker"><span>BASE 01</span> 產品試驗試制平台</div>
      <div className="base-intro-copy"><h2 id="base-title">基地資源，讓創新從想法走到試制。</h2><p>平台位於粵港澳大灣區（廣東）創新創業孵化基地 A 棟 3 樓，由廣東省人力資源社會保障廳與天河區人民政府聯合打造，整合先進製造、數字創意、高端軟件與人工智能等資源。</p></div>
      <dl><div><dt>5</dt><dd>核心功能區</dd></div><div><dt>4</dt><dd>配套服務</dd></div><div><dt>1+12+N</dt><dd>港澳創新網絡</dd></div></dl>
    </section>

    <nav className="base-anchor-nav" aria-label="基地頁面章節">
      <a href="#shared-home">共享家計劃</a><a href="#base-zones">核心分區</a><a href="#platform-guide">平台教學</a><a href="#base-contact">聯絡基地</a>
    </nav>

    <section className="shared-home" id="shared-home" aria-labelledby="shared-home-title">
      <div className="shared-home-main">
        <span className="section-number">05 / FLAGSHIP PROGRAM</span>
        <div className="shared-home-mark"><BaseIcon name="home" /></div>
        <p className="eyebrow">資源共享・協同創新</p>
        <h2 id="shared-home-title">共享家計劃</h2>
        <p className="shared-home-lead">面向「1+12+N」港澳青年創新創業基地、科研機構及各類創新主體，全面開放試驗試制資源申請服務。</p>
        <p>計劃依託基地設備與專業營運能力，建立資源共享平台。使用者可預約產品試驗試制設備、獲取技術支援及配套服務，推動創意快速完成原型驗證與成果轉化。</p>
        <div className="shared-home-tags"><span>港澳青年</span><span>科研機構</span><span>創新團隊</span><span>初創企業</span></div>
        <a className="shared-home-cta" href="mailto:GBABASE@Hotmail.com">聯絡基地申請服務 <span aria-hidden="true">→</span></a>
      </div>
      <aside className="shared-home-aside" aria-label="共享家計劃重點">
        <div><small>計劃定位</small><strong>化基地特色資源為可使用、可預約、可獲支援的公共服務。</strong></div>
        <div><small>共享機制</small><strong>動態化資源共享，強化科研協同，服務更多創新項目。</strong></div>
        <div><small>服務結果</small><strong>降低試制門檻、縮短研發週期，讓創意更快落地。</strong></div>
      </aside>
    </section>

    <section className="base-section" aria-labelledby="services-title">
      <header className="base-section-head"><div><p>03 / SUPPORT</p><h2 id="services-title">配套服務</h2></div><span>從需求判斷到安全操作，形成完整支援鏈。</span></header>
      <div className="support-grid">{supportServices.map(([title, label, description, icon]) => <article key={title}><div className="base-icon"><BaseIcon name={icon} /></div><small>{label}</small><h3>{title}</h3><p>{description}</p></article>)}</div>
    </section>

    <section className="smart-plan" aria-labelledby="smart-plan-title">
      <div className="smart-plan-copy"><p>04 / 智「匯」規劃</p><h2 id="smart-plan-title">智擎 AI 創新賦能中心</h2><strong>開啟智創時代新引擎</strong><p>整合可信數智增強創新聯合體資源，以「共享、共創、共贏」為理念，為基地項目注入 AI 動力，打造 AI 浪潮中的全鏈路創新服務生態樞紐。</p><div className="smart-roles"><span><b>全流程賦能</b>從場景設計到落地驗證</span><span><b>創新升級</b>推動企業 AI 應用啟動</span><span><b>商業增長</b>建立專屬智能代理</span></div></div>
      <div className="smart-capability-grid">{smartCapabilities.map(([title, text], index) => <article key={title}><span>{String(index + 1).padStart(2, '0')}</span><h3>{title}</h3><p>{text}</p></article>)}</div>
    </section>

    <section className="base-section" id="base-zones" aria-labelledby="zones-title">
      <header className="base-section-head"><div><p>02 / FACILITIES</p><h2 id="zones-title">五大核心分區</h2></div><span>把設計、製作、檢測、展示與創業協作放在同一條路徑上。</span></header>
      <div className="zone-list">{zones.map(([number, title, description, icon]) => <article key={number}><span className="zone-number">{number}</span><div className="base-icon"><BaseIcon name={icon} /></div><div><h3>{title}</h3><p>{description}</p></div></article>)}</div>
    </section>

    <section className="platform-guide" id="platform-guide" aria-labelledby="guide-title">
      <header><div className="base-icon"><BaseIcon name="book" /></div><div><p>PDF / 產品試驗試制平台 App 教學與開發完整大綱</p><h2 id="guide-title">從「不知道設備怎麼用」到獨立完成原型試制</h2></div></header>
      <div className="learning-objectives"><strong>完成學習後，你將能夠</strong><ul><li>了解平台資源與主要功能</li><li>依身份與專案取得推薦</li><li>查找設備並理解能力邊界</li><li>準備預約資料與安全使用</li><li>以 AI 判斷方案可行性</li><li>根據結果修改原型方案</li></ul></div>
      <div className="curriculum-list">{curriculum.map((section, index) => <section className={openSection === index ? 'curriculum-item open' : 'curriculum-item'} key={section.title}><button type="button" aria-expanded={openSection === index} aria-controls={`curriculum-panel-${index}`} onClick={() => setOpenSection((current) => current === index ? -1 : index)}>{section.title}<span aria-hidden="true">＋</span></button>{openSection === index && <div id={`curriculum-panel-${index}`}>{section.content}</div>}</section>)}</div>
      <div className="learning-path"><div><p>15 / LEARNING PATH</p><h3>完整 14 步學習路徑</h3></div><ol>{learningPath.map((step, index) => <li key={step}><span>{String(index + 1).padStart(2, '0')}</span>{step}</li>)}</ol></div>
      <blockquote>最終成果：提出產品想法 → 判斷是否適合 3D 列印 → 選擇設備與準備資料 → 完成預約與試制 → 保存結果與復盤 → 使用 AI 持續優化。</blockquote>
    </section>

    <section className="base-contact" id="base-contact" aria-labelledby="contact-title">
      <div><p>VISIT & CONTACT</p><h2 id="contact-title">把你的下一個原型帶到基地。</h2><span>廣州市天河區天慧路 10 號 A 棟 3 樓<br />產品試驗試制平台</span></div>
      <a href="mailto:GBABASE@Hotmail.com">GBABASE@Hotmail.com <span aria-hidden="true">↗</span></a>
    </section>
  </div>
}
