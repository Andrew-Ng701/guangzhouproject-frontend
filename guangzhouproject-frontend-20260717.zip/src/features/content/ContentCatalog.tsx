import { createContext, useContext, useMemo, useState, type ReactNode } from 'react'
import { equipmentSeed, eventSeed, resourceSeed } from '../admin/repository'
import type { EquipmentContent, EventContent, LearningResourceContent, PublishStatus } from '../admin/types'

type ContentCatalog = {
  equipment: EquipmentContent[]
  resources: LearningResourceContent[]
  events: EventContent[]
  createEquipment: (item: Omit<EquipmentContent, 'id'>) => void
  updateEquipment: (id: string, item: Omit<EquipmentContent, 'id'>) => void
  setEquipmentStatus: (id: string, status: PublishStatus) => void
  createResource: (item: Omit<LearningResourceContent, 'id'>) => void
  updateResource: (id: string, item: Omit<LearningResourceContent, 'id'>) => void
  setResourceStatus: (id: string, status: PublishStatus) => void
  createEvent: (item: Omit<EventContent, 'id'>) => void
  updateEvent: (id: string, item: Omit<EventContent, 'id'>) => void
  setEventStatus: (id: string, status: PublishStatus) => void
}

const ContentCatalogContext = createContext<ContentCatalog | null>(null)

function createId(prefix: string) {
  return `${prefix}-${crypto.randomUUID()}`
}

export function ContentCatalogProvider({ children }: { children: ReactNode }) {
  const [equipment, setEquipment] = useState<EquipmentContent[]>(() => structuredClone(equipmentSeed))
  const [resources, setResources] = useState<LearningResourceContent[]>(() => structuredClone(resourceSeed))
  const [events, setEvents] = useState<EventContent[]>(() => structuredClone(eventSeed))

  const value = useMemo<ContentCatalog>(() => ({
    equipment,
    resources,
    events,
    createEquipment: (item) => setEquipment((current) => [...current, { ...item, id: createId('EQ') }]),
    updateEquipment: (id, item) => setEquipment((current) => current.map((record) => record.id === id ? { ...item, id } : record)),
    setEquipmentStatus: (id, status) => setEquipment((current) => current.map((record) => record.id === id ? { ...record, status } : record)),
    createResource: (item) => setResources((current) => [...current, { ...item, id: createId('RS') }]),
    updateResource: (id, item) => setResources((current) => current.map((record) => record.id === id ? { ...item, id } : record)),
    setResourceStatus: (id, status) => setResources((current) => current.map((record) => record.id === id ? { ...record, status } : record)),
    createEvent: (item) => setEvents((current) => [...current, { ...item, id: createId('EV') }]),
    updateEvent: (id, item) => setEvents((current) => current.map((record) => record.id === id ? { ...item, id } : record)),
    setEventStatus: (id, status) => setEvents((current) => current.map((record) => record.id === id ? { ...record, status } : record)),
  }), [equipment, resources, events])

  return <ContentCatalogContext.Provider value={value}>{children}</ContentCatalogContext.Provider>
}

export function useContentCatalog() {
  const catalog = useContext(ContentCatalogContext)
  if (!catalog) throw new Error('useContentCatalog must be used within ContentCatalogProvider')
  return catalog
}
