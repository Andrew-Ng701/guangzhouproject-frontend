export type PublishStatus = 'draft' | 'published' | 'archived' | 'ended' | 'cancelled'

export interface AdminSession {
  name: string
  email: string
  role: 'admin'
}

export interface EquipmentContent {
  id: string
  name: string
  type: string
  location: string
  materials: string[]
  description: string
  specifications: string
  safetyNote: string
  availability: 'available' | 'maintenance' | 'paused'
  status: PublishStatus
}

export interface LearningResourceContent {
  id: string
  title: string
  category: '入門指南' | '設計技巧' | '問題排除'
  level: string
  duration: string
  contentUrl: string
  sortOrder: number
  status: PublishStatus
}

export interface EventContent {
  id: string
  title: string
  tag: string
  startsAt: string
  location: string
  description: string
  status: PublishStatus
}

export type AdminView = 'dashboard' | 'equipment' | 'resources' | 'events'
