import type { EquipmentContent, EventContent, LearningResourceContent, PublishStatus } from './types'

export interface ContentRepository<T extends { id: string; status: PublishStatus }> {
  list(): Promise<T[]>
  create(item: Omit<T, 'id'>): Promise<T>
  update(id: string, item: Omit<T, 'id'>): Promise<T>
  setStatus(id: string, status: PublishStatus): Promise<T>
}

export const equipmentSeed: EquipmentContent[] = [
  { id: 'EQ-01', name: 'Raise3D Pro3 Plus', type: 'FDM', location: 'A 區・製作間', materials: ['PLA', 'PETG', 'TPU'], description: '適合原型、治具與中大型結構件的雙噴頭 FDM 設備。', specifications: '建置尺寸 300 × 300 × 605 mm', safetyNote: '使用前確認材料與噴頭溫度。', availability: 'available', status: 'published' },
  { id: 'EQ-02', name: 'Formlabs Form 4', type: 'SLA', location: 'B 區・精密間', materials: ['標準樹脂', '韌性樹脂'], description: '高精度樹脂列印，適用外觀模型與細節零件。', specifications: '建置尺寸 200 × 125 × 210 mm', safetyNote: '需完成樹脂安全檢查。', availability: 'maintenance', status: 'published' },
  { id: 'EQ-03', name: 'xTool S1', type: '雷射加工', location: 'C 區・加工協作區', materials: ['木材', '壓克力'], description: '用於快速切割與雕刻，適合原型外觀與組裝零件。', specifications: '工作範圍 498 × 330 mm', safetyNote: '操作前請確認排煙系統與材料安全性。', availability: 'available', status: 'published' },
]

export const resourceSeed: LearningResourceContent[] = [
  { id: 'RS-01', title: '第一次 3D 列印：從模型到成品', category: '入門指南', level: '新手', duration: '18 分鐘', contentUrl: 'https://example.com/intro', sortOrder: 1, status: 'published' },
  { id: 'RS-02', title: 'FDM 支撐與方向設計要點', category: '設計技巧', level: '基礎', duration: '12 分鐘', contentUrl: 'https://example.com/fdm', sortOrder: 2, status: 'draft' },
  { id: 'RS-03', title: '列印失敗的初步排除', category: '問題排除', level: '中階', duration: '8 分鐘', contentUrl: 'https://example.com/troubleshooting', sortOrder: 3, status: 'published' },
]

export const eventSeed: EventContent[] = [
  { id: 'EV-01', title: '生成式設計與快速試制工作坊', tag: '工作坊', startsAt: '2026-07-22T14:00', location: '創客基地 2F', description: '從需求到可製作檔案的實作工作坊。', status: 'published' },
  { id: 'EV-02', title: '材料選擇公開諮詢', tag: '分享會', startsAt: '2026-07-25T10:30', location: '線上直播', description: '比較常用材料的製作特性與使用情境。', status: 'draft' },
  { id: 'EV-03', title: '創業團隊原型交流會', tag: '交流活動', startsAt: '2026-07-30T13:00', location: '創意試制基地', description: '分享原型測試經驗與下一輪優化方向。', status: 'published' },
]

export function createMemoryRepository<T extends { id: string; status: PublishStatus }>(seed: T[], prefix: string): ContentRepository<T> {
  let records = structuredClone(seed)
  return {
    async list() { return structuredClone(records) },
    async create(item) {
      const record = { ...item, id: `${prefix}-${Date.now()}` } as T
      records = [...records, record]
      return structuredClone(record)
    },
    async update(id, item) {
      const record = { ...item, id } as T
      records = records.map((current) => current.id === id ? record : current)
      return structuredClone(record)
    },
    async setStatus(id, status) {
      const current = records.find((record) => record.id === id)
      if (!current) throw new Error('找不到指定內容')
      const record = { ...current, status }
      records = records.map((currentRecord) => currentRecord.id === id ? record : currentRecord)
      return structuredClone(record)
    },
  }
}
